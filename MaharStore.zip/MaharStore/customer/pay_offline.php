<center><!--  center Begin  -->
    
    <h1> Pay Offline Using Method </h1>

    <p class="text-muted">
        
        If you have any questions, feel free to <a href="../contact.php">Contact Us</a>. Our Customer Service work <strong>24/7</strong>
        
    </p>
    
</center><!--  center Finish  -->

<hr>


<div class="table-responsive"><!--  table-responsive Begin  -->
    
    <table class="table table-bordered table-hover table-striped"><!--  table table-bordered table-hover Begin  -->
        
        <thead><!--  thead Begin  -->
            
            <tr><!--  tr Begin  -->
                
                <th> Bank Account Details: </th>
                <th> Easy Paisa,UBL Omni,Mobi Cash Details: </th>
                <th> Western Union Details: </th>
                
            </tr><!--  tr Finish  -->
            
        </thead><!--  thead Finish  -->
        
        <tbody><!--  tbody Begin  -->
         <td> Bank Name: UBL | Account No: 190-990-987 | Branch Name: Lahore | Branch code: 1234</td>
         <td> NIC #960-234-098 | Mobile No: +923320729939 | Name: Ishaq Mahar</td>
         <td> Real Name: Muhammad Ishaq | Mobile No: +923320729939 Country: Pakistan | Name: Ishaq Mahar | NIC #960-234-098  </td>
        </tbody><!--  tbody Finish  -->
        
    </table><!--  table table-bordered table-hover Finish  -->
    
</div><!--  table-responsive Finish  -->