<center><!-- center Begin -->
<h1> Do You Want To Delete Your Account ?</h1>
<form action="" method="post"><!-- form Begin -->
<input type="submit" name="Yes" value="Yes, I want to Delete" class="btn btn-danger">
<input type="submit" name="No" value="No, I don't want to Delete" class="btn btn-primary">
</form><!-- form Finish -->


</center><!-- center Finish -->