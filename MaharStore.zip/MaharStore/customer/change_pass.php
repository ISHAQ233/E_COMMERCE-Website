<h1 align="center"> Change  Your Password </h1>
<form action="" method="post" enctype="multipart/form-data"><!-- form Begin -->
<div class="form-group"><!-- form-group Begin -->
   <label> Your Old Password:</label>
   <input type="password" name="old_pass" class="form-control" required>
</div><!-- form-group Finish -->
<div class="form-group"><!-- form-group Begin -->
   <label> Your New Password:</label>
   <input type="password" name="new_pass" class="form-control" required>
</div><!-- form-group Finish -->
<div class="form-group"><!-- form-group Begin -->
   <label> Confirm Your New Password:</label>
   <input type="password" name="new_pass_again" class="form-control" required>
</div><!-- form-group Finish -->
<div class="text-center"><!-- text-center Begin -->

<button  name="submit" class="btn btn-primary"><!-- btn btn-primary Begin -->
<i class="fa fa-user-md"></i> Update Now


</button><!-- btn btn-primary Finish -->

</div><!-- text-center Finish -->



</form><!-- form Finish -->